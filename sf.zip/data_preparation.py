# -*- coding: utf-8 -*-
"""
Created on Tue Apr 20 18:20:05 2021

@author: dq
"""

import os
import shutil
import numpy as np

"""
video_root = "dataset/UCF11/"

video_file_list = os.listdir(video_root)

for v in video_file_list:
    if not os.path.exists("dataset/trainval/train/"+v):
        os.mkdir("dataset/trainval/train/"+v)
    if not os.path.exists("dataset/trainval/validation/"+v):
        os.mkdir("dataset/trainval/validation/"+v)
        
    for f in os.listdir(video_root+v):
        if f != "Annotation":
            for h in os.listdir(os.path.join(video_root+v,f)):
                if np.random.rand() > 0.2:
                    shutil.copy(os.path.join(video_root+v,f,h), os.path.join("dataset/trainval/train/",v,h))
                else:
                    shutil.copy(os.path.join(video_root+v,f,h), os.path.join("dataset/trainval/validation/",v,h))


"""

train_root = "dataset/train/"
train_edge_root = "dataset/train_edge/"
