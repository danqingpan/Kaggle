# -*- coding: utf-8 -*-
"""
Created on Tue Apr 20 21:46:41 2021

@author: dq
"""

import cv2
import matplotlib.pyplot as plt
from skimage import color
from skimage import feature
import numpy as np
#如果要调用摄像头，则VideoCapture()的参数为0；如果读取本地视频，则要用视频地址
#cap = cv2.VideoCapture(0)
#video_path = "dataset/train/basketball/v_shooting_01_01.mpg"
#video_save_path = 'dataset/train_edge/v_shooting_01_01.mp4'

def video_change(video_path,video_save_path):
    
    cap = cv2.VideoCapture()
    cap.open(video_path)
    
    fps = cap.get(cv2.CAP_PROP_FPS) #获取视频的帧率
    size = (int(cap.get(cv2.CAP_PROP_FRAME_WIDTH)),
            int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT)))#获取视频的大小
    
    fourcc = cv2.VideoWriter_fourcc('m', 'p', '4', 'v')  #要保存的视频格式
    #fourcc = cv2.VideoWriter_fourcc('p', 'i', 'm', '2')
    #把处理过的视频保存下来
    output_video = cv2.VideoWriter()
    #保存的视频地址
    
    output_video.open(video_save_path , fourcc, fps, (320,240), True)
    
    while True:
      ret, image_np = cap.read()
    
      #plt.imshow(image_np)
      
      if image_np is not None:
          #cv2.imshow('object detection', cv2.resize(image_np, (800,600)))
          img = color.rgb2gray(image_np)
          img = feature.canny(img,sigma=0.5)
          
          img = img*255
          img = img.astype("uint8")
          
          img_rgb = np.zeros((size[1],size[0],3)).astype("uint8")
          for i in range(3):
              img_rgb[:,:,i] = img
          #print(img_rgb)   
          #break
          #print(image_np.shape)
          #print(image_np)
          #break
          output_video.write(img_rgb)
          
          #cv2.imshow('object detection', cv2.resize(img, (800,600)))
          #if cv2.waitKey(25) & 0xFF == ord('q'):
          #    cv2.destroyAllWindows()
          #    break
      else:
          #cv2.destroyAllWindows()
          break
      #此处省略对image_np的处理，此为一帧图片
      #cv2.imshow('object detection', cv2.resize(image_np, (800,600)))#显示图片
      #output_video.write(image_np) #把帧写入到视频中
      #if cv2.waitKey(25) & 0xFF == ord('q'):
      #    cv2.destroyAllWindows()
      #    break
    
    output_video.release()#释放
    cap.release()#释放

"""
video_path = "dataset/train/basketball/v_shooting_01_01.mp4"
video_save_path = 'dataset/v_shooting_01_01.mp4'
#video_change(video_path,video_save_path)

cap = cv2.VideoCapture()
cap.open(video_path)

fps = cap.get(cv2.CAP_PROP_FPS) #获取视频的帧率
size = (int(cap.get(cv2.CAP_PROP_FRAME_WIDTH)),
        int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT)))#获取视频的大小

print(size)
"""

import os

normal_root = "dataset/validation_RGB/"
edge_root = "dataset/validation/"

for cls in os.listdir(normal_root):
    for c_file in os.listdir(normal_root+cls):
        if not os.path.exists(os.path.join(edge_root,cls)):
            os.mkdir(os.path.join(edge_root,cls))
        video_change(os.path.join(normal_root,cls,c_file),os.path.join(edge_root,cls,c_file[:-4]+".mp4"))
        
        
    



